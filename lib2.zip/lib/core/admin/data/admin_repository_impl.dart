import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:spark_app/core/admin/domain/admin_repository.dart';

// ─────────────────────────────────────────────────────────────────
//  ADMIN REPOSITORY IMPL — DATA LAYER (Firestore)
// ─────────────────────────────────────────────────────────────────

class AdminRepositoryImpl implements AdminRepository {
  final _db = FirebaseFirestore.instance;

  CollectionReference _col(String name) => _db.collection(name);

  // ── CATEGORIES ───────────────────────────────────────────────────
  @override
  Stream<QuerySnapshot> readCategories() =>
      _col('categories').orderBy('title').snapshots();

  @override
  Future<void> createCategory(Map<String, dynamic> data) =>
      _col('categories').add({...data, 'createdAt': FieldValue.serverTimestamp()});

  @override
  Future<void> updateCategory(String id, Map<String, dynamic> data) =>
      _col('categories').doc(id).update({...data, 'updatedAt': FieldValue.serverTimestamp()});

  @override
  Future<void> deleteCategory(String id) =>
      _col('categories').doc(id).delete();

  // ── MODULES ──────────────────────────────────────────────────────
  @override
  Stream<QuerySnapshot> readModules() =>
      _col('modules').orderBy('title').snapshots();

  @override
  Future<void> createModule(Map<String, dynamic> data) =>
      _col('modules').add({...data, 'createdAt': FieldValue.serverTimestamp()});

  @override
  Future<void> updateModule(String id, Map<String, dynamic> data) =>
      _col('modules').doc(id).update({...data, 'updatedAt': FieldValue.serverTimestamp()});

  @override
  Future<void> deleteModule(String id) =>
      _col('modules').doc(id).delete();

  // ── LESSONS ──────────────────────────────────────────────────────
  @override
  Stream<QuerySnapshot> readLessons() =>
      _col('lessons').orderBy('title').snapshots();

  @override
  Future<void> createLesson(Map<String, dynamic> data) =>
      _col('lessons').add({...data, 'createdAt': FieldValue.serverTimestamp()});

  @override
  Future<void> updateLesson(String id, Map<String, dynamic> data) =>
      _col('lessons').doc(id).update({...data, 'updatedAt': FieldValue.serverTimestamp()});

  @override
  Future<void> deleteLesson(String id) =>
      _col('lessons').doc(id).delete();

  // ── QUESTIONS ────────────────────────────────────────────────────
  @override
  Stream<QuerySnapshot> readQuestions() =>
      _col('questions').orderBy('statement').snapshots();

  @override
  Future<void> createQuestion(Map<String, dynamic> data) =>
      _col('questions').add({...data, 'createdAt': FieldValue.serverTimestamp()});

  @override
  Future<void> updateQuestion(String id, Map<String, dynamic> data) =>
      _col('questions').doc(id).update({...data, 'updatedAt': FieldValue.serverTimestamp()});

  @override
  Future<void> deleteQuestion(String id) =>
      _col('questions').doc(id).delete();
}
