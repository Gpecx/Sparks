import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../theme/app_theme.dart';
import '../../../constants/fs.dart';
import '../admin_controller.dart';
import 'admin_entity_form.dart';

class AdminDialogs {
  static Future<void> showCreateCategory(BuildContext context, WidgetRef ref) async {
    await showDialog<String>(
      context: context,
      barrierDismissible: true,
      builder: (ctx) => AdminEntityForm(
        title: 'Nova Categoria',
        fields: const [
          FieldConfig(key: FS.title, label: 'Título', required: true),
          FieldConfig(key: 'description', label: 'Descrição', maxLines: 3),
          FieldConfig(key: 'icon', label: 'Emoji ou Ícone (Ex: 🚀)', hint: 'Escolha um símbolo marcante', required: false),
          FieldConfig(key: 'imageUrl', label: 'URL da Imagem de Capa', hint: 'https://exemplo.com/imagem.png', required: false),
        ],
        onSave: (data) async {
          final id = await ref.read(adminControllerProvider.notifier).create(AdminEntity.categories, data);
          return id ?? '';
        },
      ),
    );
  }

  static Future<void> showEditCategory(BuildContext context, WidgetRef ref, String catId, Map<String, dynamic> data) async {
    await showDialog(
      context: context,
      barrierDismissible: true,
      builder: (ctx) => AdminEntityForm(
        title: 'Editar Categoria',
        initialValues: data.map((k, v) => MapEntry(k, v.toString())),
        fields: const [
          FieldConfig(key: FS.title, label: 'Título', required: true),
          FieldConfig(key: 'description', label: 'Descrição', maxLines: 3),
          FieldConfig(key: 'icon', label: 'Emoji ou Ícone', required: false),
          FieldConfig(key: 'imageUrl', label: 'URL da Imagem', required: false),
        ],
        onSave: (newData) async {
          await ref.read(adminControllerProvider.notifier).update(AdminEntity.categories, catId, newData);
          return 'ok';
        },
      ),
    );
  }

  static Future<void> showCreateModule(BuildContext context, WidgetRef ref) async {
    await showDialog<String>(
      context: context,
      barrierDismissible: true,
      builder: (ctx) => AdminEntityForm(
        title: 'Novo Módulo',
        fields: const [
          FieldConfig(key: FS.title, label: 'Título do Módulo', required: true),
          FieldConfig(key: 'subtitle', label: 'Subtítulo/Descrição'),
          FieldConfig(key: 'icon', label: 'Ícone (Ex: 📘)', required: false),
          FieldConfig(key: 'imageUrl', label: 'URL da Imagem', required: false),
        ],
        onSave: (data) async {
          final id = await ref.read(adminControllerProvider.notifier).create(AdminEntity.modules, data);
          return id ?? '';
        },
      ),
    );
  }

  static Future<void> showEditModule(BuildContext context, WidgetRef ref, String modId, Map<String, dynamic> data) async {
    await showDialog(
      context: context,
      barrierDismissible: true,
      builder: (ctx) => AdminEntityForm(
        title: 'Editar Módulo',
        initialValues: data.map((k, v) => MapEntry(k, v.toString())),
        fields: const [
          FieldConfig(key: FS.title, label: 'Título do Módulo', required: true),
          FieldConfig(key: 'subtitle', label: 'Subtítulo/Descrição'),
          FieldConfig(key: 'icon', label: 'Ícone', required: false),
          FieldConfig(key: 'imageUrl', label: 'URL da Imagem', required: false),
        ],
        onSave: (newData) async {
          await ref.read(adminControllerProvider.notifier).update(AdminEntity.modules, modId, newData);
          return 'ok';
        },
      ),
    );
  }

  static Future<void> showTrailWizard(BuildContext context, WidgetRef ref) async {
    final titleCtrl = TextEditingController();
    final lessonsCtrl = TextEditingController(text: '4');
    final quizzesCtrl = TextEditingController(text: '1');
    final questionsCtrl = TextEditingController(text: '5');
    
    await showDialog(
      context: context,
      builder: (ctx) {
        final size = MediaQuery.of(ctx).size;
        final isDesktop = size.width > 900;
        
        return Dialog(
          backgroundColor: Colors.transparent,
          child: Container(
            width: isDesktop ? 500 : double.infinity,
            padding: const EdgeInsets.all(32),
            decoration: BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: AppColors.orange.withValues(alpha: 0.3)),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: AppColors.orange.withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Icon(Icons.auto_awesome, color: AppColors.orange),
                    ),
                    const SizedBox(width: 16),
                    const Expanded(
                      child: Text(
                        'Gerar Estrutura de Trilha',
                        style: TextStyle(
                          color: AppColors.textPrimary,
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                const Text(
                  'Isso criará a trilha com lições e questões vazias prontas para receber conteúdo.',
                  style: TextStyle(color: AppColors.textSecondary, fontSize: 13),
                ),
                const SizedBox(height: 24),
                TextField(
                  controller: titleCtrl,
                  decoration: const InputDecoration(labelText: 'Título da Trilha'),
                  style: const TextStyle(color: Colors.white),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: lessonsCtrl,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(labelText: 'Qtd. Lições'),
                        style: const TextStyle(color: Colors.white),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: TextField(
                        controller: quizzesCtrl,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(labelText: 'Qtd. Provas'),
                        style: const TextStyle(color: Colors.white),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: questionsCtrl,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'Questões por Prova'),
                  style: const TextStyle(color: Colors.white),
                ),
                const SizedBox(height: 32),
                Row(
                  children: [
                    Expanded(
                      child: TextButton(
                        onPressed: () => Navigator.pop(ctx),
                        child: const Text('CANCELAR', style: TextStyle(color: AppColors.textSecondary)),
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(backgroundColor: AppColors.orange),
                        onPressed: () async {
                          final success = await ref.read(adminControllerProvider.notifier).generateTrail(
                            title: titleCtrl.text,
                            numLessons: int.tryParse(lessonsCtrl.text) ?? 0,
                            numEvaluations: int.tryParse(quizzesCtrl.text) ?? 0,
                            questionsPerLesson: 0,
                            questionsPerEvaluation: int.tryParse(questionsCtrl.text) ?? 0,
                          );
                          if (success && ctx.mounted) {
                            Navigator.pop(ctx);
                            await showDialog(
                              context: context,
                              builder: (c) => const AdminSuccessDialog(message: 'Estrutura da Trilha gerada!'),
                            );
                          }
                        },
                        child: const Text('GERAR'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
