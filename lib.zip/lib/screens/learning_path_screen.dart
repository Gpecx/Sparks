import 'package:flutter/material.dart';
import 'package:spark_app/theme/app_theme.dart';
import 'package:spark_app/screens/quiz_screen.dart';
import 'package:spark_app/controllers/energy_controller.dart';
import 'package:spark_app/widgets/sparks_background.dart';

class LearningPathScreen extends StatefulWidget {
  const LearningPathScreen({super.key});
  @override
  State<LearningPathScreen> createState() => _LearningPathScreenState();
}

class _LearningPathScreenState extends State<LearningPathScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  final EnergyController _energyCtrl = EnergyController();

  int _completedLessons = 5;

  // 22 nós: 10 lições + 1 avaliação + 10 lições + 1 avaliação
  final List<Map<String, dynamic>> _nodes = [];

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    )..repeat(reverse: true);
    _energyCtrl.addListener(_onEnergyChanged);

    // Popula a trilha
    for (int i = 1; i <= 10; i++) {
      _nodes.add({'type': 'lesson', 'title': 'Lição $i', 'subtitle': 'Módulo Base'});
    }
    _nodes.add({'type': 'eval', 'title': 'AVALIAÇÃO 1', 'subtitle': 'Certificado Básico'});
    for (int i = 1; i <= 10; i++) {
      _nodes.add({'type': 'lesson', 'title': 'Lição ${i + 10}', 'subtitle': 'Módulo Avançado'});
    }
    _nodes.add({'type': 'eval', 'title': 'AVALIAÇÃO 2', 'subtitle': 'Certificado Final'});
  }

  void _onEnergyChanged() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _controller.dispose();
    _energyCtrl.removeListener(_onEnergyChanged);
    super.dispose();
  }

  bool _isNodeUnlocked(int index) => index <= _completedLessons;

  bool get _canAccessEvaluation1 => _completedLessons >= 10;
  bool get _canAccessEvaluation2 => _completedLessons >= 21;

  double get _progressValue => (_completedLessons > 22 ? 22 : _completedLessons) / 22;

  void _handleNodeTap(int index) async {
    if (!_isNodeUnlocked(index)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Módulo bloqueado! Conclua as lições anteriores primeiro.'),
          backgroundColor: AppColors.error,
        ),
      );
      return;
    }

    final node = _nodes[index];
    if (node['type'] == 'eval') {
      if ((index == 10 && _canAccessEvaluation1) || (index == 21 && _canAccessEvaluation2)) {
        final passed = await Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => QuizScreen(isEvaluation: true)),
        );
        if (passed == true && index == _completedLessons) {
          setState(() { _completedLessons++; });
        }
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Complete 100% das lições anteriores para a avaliação!'),
            backgroundColor: AppColors.error,
          ),
        );
      }
    } else {
      final passed = await Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => QuizScreen(isEvaluation: false)),
      );
      if (passed == true && index == _completedLessons) {
        setState(() { _completedLessons++; });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return SparksBackground(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: SafeArea(
          child: Column(
            children: [
              // ── Header ──────────────────────────────────────
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
                child: Row(
                  children: [
                    GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: const Icon(Icons.arrow_back_ios_new, color: Colors.white, size: 20),
                    ),
                    const SizedBox(width: 12),
                    const Expanded(
                      child: Text(
                        'SEGURANÇA BÁSICA',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 15,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 1.5,
                        ),
                      ),
                    ),
                    GestureDetector(
                      onTap: () => Navigator.pushNamed(context, '/store'),
                      child: _buildBadge(Icons.bolt, '250', AppColors.primary),
                    ),
                    const SizedBox(width: 10),
                    GestureDetector(
                      onTap: () => Navigator.pushNamed(context, '/store'),
                      child: ListenableBuilder(
                        listenable: _energyCtrl,
                        builder: (_, _) => _buildBatteryBadge(),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),

              // ── Card de Progresso ───────────────────────────
              Container(
                margin: const EdgeInsets.symmetric(horizontal: 20),
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: AppColors.card,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: AppColors.primary.withValues(alpha: 0.25)),
                ),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 40,
                          height: 40,
                          decoration: BoxDecoration(
                            color: AppColors.primary.withValues(alpha: 0.12),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: const Icon(Icons.menu_book, color: AppColors.primary, size: 22),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('Módulo Atual', style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w700)),
                              const SizedBox(height: 2),
                              Text(
                                'Em Progresso · $_completedLessons de ${_nodes.length} etapas',
                                style: const TextStyle(color: AppColors.textMuted, fontSize: 11),
                              ),
                            ],
                          ),
                        ),
                        Text(
                          '${(_progressValue * 100).round()}%',
                          style: const TextStyle(color: AppColors.primary, fontWeight: FontWeight.w800, fontSize: 15),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(4),
                      child: LinearProgressIndicator(
                        value: _progressValue,
                        backgroundColor: AppColors.inputBackground,
                        valueColor: const AlwaysStoppedAnimation<Color>(AppColors.primary),
                        minHeight: 5,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 8),

              // ── Trilha de Nós ───────────────────────────────
              // Usa LayoutBuilder para saber a largura disponível e calcular
              // as posições absolutas dos nós — painter e widgets compartilham
              // as mesmas funções _nodeX/_nodeY, garantindo alinhamento perfeito.
              Expanded(
                child: LayoutBuilder(
                  builder: (context, constraints) {
                    final screenWidth = constraints.maxWidth;
                    final totalHeight = _nodeY(_nodes.length - 1, screenWidth) +
                        TrailLayout.kNodeSize / 2 +
                        TrailLayout.kTextHeight +
                        80.0; // padding inferior

                    return ScrollConfiguration(
                      behavior: _NoScrollbarBehavior(),
                      child: SingleChildScrollView(
                        physics: const BouncingScrollPhysics(),
                        child: SizedBox(
                          width: screenWidth,
                          height: totalHeight,
                          child: Stack(
                            clipBehavior: Clip.none,
                            children: [
                              // ── Linhas (painter) ──────────────────
                              Positioned.fill(
                                child: CustomPaint(
                                  painter: _PathPainter(
                                    nodesCount: _nodes.length,
                                    completedCount: _completedLessons,
                                    screenWidth: screenWidth,
                                  ),
                                ),
                              ),
                              // ── Nós posicionados com coordenadas absolutas ──
                              ...List.generate(_nodes.length, (index) {
                                final node = _nodes[index];
                                final isCompleted = _completedLessons > index;
                                final isCurrent   = _completedLessons == index;
                                final isUnlocked  = _isNodeUnlocked(index);
                                final isEval      = node['type'] == 'eval';

                                final cx = _nodeX(index, screenWidth);
                                final cy = _nodeY(index, screenWidth);

                                // Largura estimada do widget do nó (centrado em cx)
                                const nodeWidgetW = 120.0;

                                return Positioned(
                                  left: cx - nodeWidgetW / 2,
                                  top:  cy - TrailLayout.kNodeSize / 2,
                                  width: nodeWidgetW,
                                  child: isEval
                                      ? _buildEvalNode(
                                          label: node['title'],
                                          subtitle: node['subtitle'],
                                          isUnlocked: isUnlocked,
                                          isCompleted: isCompleted,
                                          onTap: () => _handleNodeTap(index),
                                        )
                                      : _buildLessonNode(
                                          label: node['title'],
                                          subtitle: node['subtitle'],
                                          isCompleted: isCompleted,
                                          isCurrent: isCurrent,
                                          isUnlocked: isUnlocked,
                                          onTap: () => _handleNodeTap(index),
                                        ),
                                );
                              }),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ── Posição absoluta de cada nó ──────────────────────────────
  // Essas funções são a ÚNICA fonte de verdade para posição.
  // Tanto o Stack (widgets) quanto o _PathPainter usam exatamente elas.
  double _nodeX(int index, double screenWidth) {
    final cx = screenWidth / 2;
    final mod = index % 4;
    switch (mod) {
      case 0: return cx;
      case 1: return cx + TrailLayout.kAmplitude;
      case 2: return cx;
      case 3: return cx - TrailLayout.kAmplitude;
      default: return cx;
    }
  }

  double _nodeY(int index, double screenWidth) {
    return TrailLayout.kTopPadding +
        index * TrailLayout.kSlotHeight +
        TrailLayout.kNodeSize / 2;
  }

  // ── Nó de Lição ───────────────────────────────────────────────
  Widget _buildLessonNode({
    required String label,
    required String subtitle,
    required bool isCompleted,
    required bool isCurrent,
    required bool isUnlocked,
    required VoidCallback onTap,
  }) {
    Color nodeColor;
    Color borderColor;
    Color iconColor;
    List<BoxShadow>? glow;
    IconData icon;

    if (isCompleted) {
      nodeColor = AppColors.primary;
      borderColor = AppColors.primary;
      iconColor = Colors.white;
      icon = Icons.check;
      glow = [BoxShadow(color: AppColors.primary.withValues(alpha: 0.35), blurRadius: 18, spreadRadius: 4)];
    } else if (isCurrent) {
      nodeColor = AppColors.card;
      borderColor = AppColors.primary;
      iconColor = Colors.white;
      icon = Icons.play_arrow;
      glow = [BoxShadow(color: AppColors.primary.withValues(alpha: 0.25), blurRadius: 18, spreadRadius: 4)];
    } else {
      nodeColor = AppColors.card;
      borderColor = AppColors.textMuted.withValues(alpha: 0.2);
      iconColor = AppColors.textMuted;
      icon = Icons.lock;
      glow = null;
    }

    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Column(
        children: [
          Stack(
            clipBehavior: Clip.none,
            children: [
              Container(
                width: 64,
                height: 64,
                decoration: BoxDecoration(
                  color: nodeColor,
                  shape: BoxShape.circle,
                  border: Border.all(color: borderColor, width: 2.5),
                  boxShadow: glow,
                ),
                child: Icon(icon, color: iconColor, size: 28),
              ),
              // Estrela no nó atual
              if (isCurrent)
                Positioned(
                  top: -4,
                  right: -8,
                  child: Container(
                    width: 22,
                    height: 22,
                    decoration: const BoxDecoration(color: AppColors.gold, shape: BoxShape.circle),
                    child: const Icon(Icons.star, color: Colors.white, size: 13),
                  ),
                ),
              // Cadeado extra embaixo nos bloqueados
              if (!isUnlocked && !isCompleted)
                Positioned(
                  bottom: -4,
                  right: -4,
                  child: Container(
                    padding: const EdgeInsets.all(4),
                    decoration: const BoxDecoration(color: AppColors.card, shape: BoxShape.circle),
                    child: const Icon(Icons.lock, color: AppColors.textMuted, size: 14),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            label,
            style: TextStyle(
              color: isCurrent
                  ? AppColors.primary
                  : Colors.white.withValues(alpha: isUnlocked ? 1 : 0.35),
              fontSize: 13,
              fontWeight: FontWeight.w800,
              letterSpacing: 0.5,
            ),
          ),
          Text(
            subtitle,
            style: TextStyle(
              color: Colors.white.withValues(alpha: 0.4),
              fontSize: 11,
            ),
          ),
        ],
      ),
    );
  }

  // ── Nó de Avaliação ───────────────────────────────────────────
  Widget _buildEvalNode({
    required String label,
    required String subtitle,
    required bool isUnlocked,
    required bool isCompleted,
    required VoidCallback onTap,
  }) {
    final color = isCompleted
        ? AppColors.primary
        : isUnlocked
            ? AppColors.gold
            : AppColors.textMuted;

    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            width: 72,
            height: 72,
            decoration: BoxDecoration(
              color: isCompleted
                  ? AppColors.primary.withValues(alpha: 0.2)
                  : isUnlocked
                      ? AppColors.gold.withValues(alpha: 0.2)
                      : AppColors.card,
              shape: BoxShape.circle,
              border: Border.all(
                color: isCompleted
                    ? AppColors.primary
                    : isUnlocked
                        ? AppColors.gold
                        : AppColors.textMuted.withValues(alpha: 0.2),
                width: 2.5,
              ),
              boxShadow: (isUnlocked || isCompleted)
                  ? [BoxShadow(color: color.withValues(alpha: 0.4), blurRadius: 18, spreadRadius: 4)]
                  : null,
            ),
            child: Icon(
              isCompleted
                  ? Icons.check
                  : isUnlocked
                      ? Icons.emoji_events
                      : Icons.lock,
              color: color,
              size: 32,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            label,
            style: TextStyle(
              color: isCompleted
                  ? AppColors.primary
                  : isUnlocked
                      ? AppColors.gold
                      : Colors.white.withValues(alpha: 0.35),
              fontSize: 14,
              fontWeight: FontWeight.w900,
              letterSpacing: 0.5,
            ),
          ),
          Text(
            isCompleted
                ? 'Concluída ✓'
                : isUnlocked
                    ? 'Disponível!'
                    : 'Complete 100% antes!',
            style: TextStyle(
              color: (isCompleted || isUnlocked)
                  ? color.withValues(alpha: 0.7)
                  : Colors.white.withValues(alpha: 0.3),
              fontSize: 11,
            ),
          ),
        ],
      ),
    );
  }

  // ── Badge (Spark Points) ──────────────────────────────────────
  Widget _buildBadge(IconData icon, String value, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withValues(alpha: 0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: color, size: 16),
          const SizedBox(width: 4),
          Text(value, style: TextStyle(color: color, fontWeight: FontWeight.w700, fontSize: 13)),
        ],
      ),
    );
  }

  // ── Badge da Bateria ──────────────────────────────────────────
  Widget _buildBatteryBadge() {
    final hasEnergy = _energyCtrl.hasEnergy;
    final color = hasEnergy ? AppColors.gold : Colors.redAccent;
    IconData batteryIcon;
    final ratio = _energyCtrl.energy / EnergyController.maxEnergy;

    if (_energyCtrl.isPremiumUser) {
      batteryIcon = Icons.battery_charging_full;
    } else if (ratio >= 0.7) {
      batteryIcon = Icons.battery_full;
    } else if (ratio >= 0.4) {
      batteryIcon = Icons.battery_4_bar;
    } else if (ratio >= 0.2) {
      batteryIcon = Icons.battery_2_bar;
    } else {
      batteryIcon = Icons.battery_alert;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withValues(alpha: 0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(batteryIcon, color: color, size: 16),
          const SizedBox(width: 4),
          Text(
            _energyCtrl.energyDisplay,
            style: TextStyle(color: color, fontWeight: FontWeight.w700, fontSize: 13),
          ),
          if (_energyCtrl.isRecharging) ...[
            const SizedBox(width: 6),
            Text(
              _energyCtrl.regenTimeRemaining,
              style: const TextStyle(color: AppColors.textMuted, fontSize: 11),
            ),
          ],
        ],
      ),
    );
  }
}

// ── Constantes da trilha (fonte única de verdade) ───────────────
// Altere aqui para ajustar visual da trilha inteira.
class TrailLayout {
  /// Raio do círculo de cada nó.
  static const double kNodeSize    = 40.0;
  /// Altura aproximada do bloco de texto (label + subtitle + gap).
  static const double kTextHeight  = 38.0;
  /// Espaço extra entre o texto de um nó e o círculo do próximo.
  static const double kGapBetween  = 100.0;
  /// Altura total ocupada por um nó no eixo Y.
  static const double kSlotHeight  = kNodeSize + kTextHeight + kGapBetween;
  /// Padding do topo antes do primeiro nó.
  static const double kTopPadding  = 56.0;
  /// Quanto cada nó se afasta do centro para fazer a cobrinha.
  static const double kAmplitude   = 100.0;
}

// ── Comportamento sem scrollbar ─────────────────────────────────
class _NoScrollbarBehavior extends ScrollBehavior {
  @override
  Widget buildScrollbar(BuildContext context, Widget child, ScrollableDetails details) {
    return child;
  }
}

// ── Painter do caminho serpenteante ─────────────────────────────
// Recebe screenWidth e usa as mesmas fórmulas do widget para garantir
// que cada segmento de linha conecte exatamente os centros dos nós.
class _PathPainter extends CustomPainter {
  final int nodesCount;
  final int completedCount;
  final double screenWidth;

  const _PathPainter({
    required this.nodesCount,
    required this.completedCount,
    required this.screenWidth,
  });

  double _nodeX(int index) {
    final cx = screenWidth / 2;
    final mod = index % 4;
    switch (mod) {
      case 0: return cx;
      case 1: return cx + TrailLayout.kAmplitude;
      case 2: return cx;
      case 3: return cx - TrailLayout.kAmplitude;
      default: return cx;
    }
  }

  double _nodeY(int index) {
    return TrailLayout.kTopPadding +
        index * TrailLayout.kSlotHeight +
        TrailLayout.kNodeSize / 2;
  }

  @override
  void paint(Canvas canvas, Size size) {
    if (nodesCount < 2) return;

    final glowPaint = Paint()
      ..color = AppColors.primary.withValues(alpha: 0.18)
      ..strokeWidth = 16
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 7);

    final completedPaint = Paint()
      ..color = AppColors.primary
      ..strokeWidth = 4
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    final lockedPaint = Paint()
      ..color = AppColors.textMuted.withValues(alpha: 0.2)
      ..strokeWidth = 3
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    final completedPath = Path();
    final lockedPath   = Path();

    for (int i = 0; i < nodesCount - 1; i++) {
      final sx = _nodeX(i);
      final sy = _nodeY(i);
      final ex = _nodeX(i + 1);
      final ey = _nodeY(i + 1);

      // A linha começa na borda inferior do círculo e termina na borda superior
      final r = TrailLayout.kNodeSize / 20 + 4.0;
      final startY = sy + r;
      final endY   = ey - r;
      final segH   = endY - startY;

      final path = Path()..moveTo(sx, startY);

      // Bezier cúbica suave — cp1 e cp2 controlam a curvatura
      final cp1x = sx + (ex - sx) * 0.8;
final cp1y = startY + segH * 0.3;
final cp2x = ex - (ex - sx) * 0.8;
final cp2y = endY   - segH * 0.3;

      path.cubicTo(cp1x, cp1y, cp2x, cp2y, ex, endY);

      if (i < completedCount) {
        completedPath.addPath(path, Offset.zero);
      } else {
        lockedPath.addPath(path, Offset.zero);
      }
    }

    canvas.drawPath(completedPath, glowPaint);
    canvas.drawPath(completedPath, completedPaint);
    canvas.drawPath(lockedPath,    lockedPaint);
  }

  @override
  bool shouldRepaint(covariant _PathPainter old) =>
      old.completedCount != completedCount ||
      old.nodesCount     != nodesCount     ||
      old.screenWidth    != screenWidth;
}